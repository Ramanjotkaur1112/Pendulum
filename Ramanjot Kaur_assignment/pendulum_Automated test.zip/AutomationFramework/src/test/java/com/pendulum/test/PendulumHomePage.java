package com.pendulum.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.testng.annotations.Test;


import io.github.bonigarcia.wdm.WebDriverManager;

public class PendulumHomePage {

	PendulumHomePage pendulumHomePage;
WebDriver driver;
	
	
	
	@FindBy(id="set")
	WebElement set;
	
	@FindBy(id="start")
	WebElement start;
	
	@FindBy(id="pause")
	WebElement pause;
	
	@FindBy(id="reset")
	WebElement reset;
	
	@FindBy(id="export")
	WebElement export;
	
	public PendulumHomePage(WebDriver driver) {
		this.driver = driver;
        PageFactory.initElements(driver, this);
	}
	
	
	public void clickPauseButton() {
		pause.click();
	}
	
	public void clickStartButton() {
		start.click();
	}
	
	public void clickSetButton() {
		set.click();
	}
	
	public void clickResetButton() {
		reset.click();
	}
	
	public void clickExportButton() {
		export.click();
	}
	
	public PendulumHomePage verifySet() {
		log.info("click on Set button - " );
		clickSetButton();
		return new PendulumHomePage(driver);
	}
	
	
	public PendulumHomePage verifyStart() {
		log.info("click on Start button - " );
		clickStartButton();
		return new PendulumHomePage(driver);
	}
	
	public PendulumHomePage verifyPause() {
		log.info("click on Pause button - " );
		clickPauseButton();
		return new PendulumHomePage(driver);
	}
	
	public PendulumHomePage verifyReset() {
		log.info("click on ReSet button - " );
		clickResetButton();
		return new PendulumHomePage(driver);
	}
	
	public PendulumHomePage verifyExport() {
		log.info("click on Export button - " );
		clickExportButton();
		return new PendulumHomePage(driver);
	}
	
	public String getTitle() {
		return driver.getTitle();
	}
	

	//Log4j configuration
	private static final Logger log = LogManager.getLogger(PendulumHomePage.class);
	
	@Test
	public void verifyClick(){
			
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			 driver.get("file:///C:/Users/91816/Downloads/PendulumAssignment-main/PendulumAssignment-main/frontend/index.html");
			
		
		
		
		
		pendulumHomePage = new PendulumHomePage(driver);
		
		//Should click on buttons
	clickSetButton();
	clickStartButton();
	clickPauseButton();
	clickResetButton();
	clickExportButton();
		
		
		log.info("Thanks !! ");
		
	}
	

}
